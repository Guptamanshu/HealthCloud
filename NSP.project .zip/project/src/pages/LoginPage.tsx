import React from 'react';
import { AuthForm } from '../components/auth/AuthForm';

export const LoginPage = () => {
  return <AuthForm type="login" />;
};