import React from 'react';
import { AuthForm } from '../components/auth/AuthForm';

export const RegisterPage = () => {
  return <AuthForm type="register" />;
};